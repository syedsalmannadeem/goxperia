module LocationsHelper

end
