class AddPreferredToLocations < ActiveRecord::Migration[6.0]
  def change
    add_column :locations, :preferred, :boolean
  end
end
